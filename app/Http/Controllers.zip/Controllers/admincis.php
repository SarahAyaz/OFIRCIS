<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class admincis extends Controller
{
    
    public function admin_dashboard()  //police site police-dashboard.php
    {
        return view('cisps/admin/admin-dashboard');
    }
    public function createacc()  //police site search-fir.php
    {
        return view('cisps/admin/add-police-station');
    }
    public function viewacc()  //police site search-fir-result.php
    {
        return view('cisps/admin/view-police-station');
    }
    public function sms_service()  //police site verify-fir.php
    {
        return view('cisps/admin/sms-service-account');
    }
     public function help()  //police site verify-fir.php
    {
        return view('cisps/admin/help');
    }
}
