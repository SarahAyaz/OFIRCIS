<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class fircs extends Controller
{
    

	public function homepage()  //homepage of client site index.php
    {
        return view('ofircs/index');
    }
    public function myprofile() //client site my-profile.php
    {
        return view('ofircs/my-profile');
    }

    public function my_profile_running() //client site my-profile-runnning.php all runnning firs
    {
        return view('ofircs/my-profile-running');
    }


    public function my_profile_pending() //client site my-profile-pending.php all pending  firs
    {
        return view('ofircs/my-profile-pending');
    }

    public function my_profile_all_firs() //client site my-profile-all-firs.php all  firs
    {
        return view('ofircs/my-profile-all-fir');
    }


    public function my_profile_delete_account() //client site my-profile-delete-account.php delete accounts 
    {
        return view('ofircs/my-profile-delete-account');
    }

    public function view_fir_details() //client site view-fir-details.blade firs Details form
    {
        return view('ofircs/view-fir-details');

    }

    public function fir_form() //client site fir-form.blade.php firs form   
    {
        return view('ofircs/fir-form');

    }

    public function fir_verify() //client site fir-verify.blade f.php verify FIR form   
    {
        return view('ofircs/fir-verify');

    }


 	public function forget_password() //client site forget-password.blade.php Password forget page   
    {
        return view('ofircs/forget-password');

    }



    public function forget_password_verify() //client site forget-password-verify.blade Password forget verificatioj page  
    {
        return view('ofircs/forget-password-verify');

    }

    public function print_fir() //client site print-fir.blade.php Print FIR button page
    {
        return view('ofircs/print-fir');

    }
 
  	public function print_fir_pdf() //client site print-fir-pdf.blade Print FIR pdf  page
    {
        return view('ofircs/print-fir-pdf');

    }

    public function reset_password() //client site reset-password.blade.php Reset Password
    {
        return view('ofircs/reset-password');

    }


    public function signup() //client site signup.blade.php Sign Up page
    {
       return view('ofircs/signup');

    }
    public function contact() //client site signup.blade.php Sign Up page
    {
       return view('ofircs/contact-us');

    }




    //test of cis site in this controller

 












}
